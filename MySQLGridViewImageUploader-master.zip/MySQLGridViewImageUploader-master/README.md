# MySQLGridViewImageUploader
This is a tutorial on how to upload and download images and text to and from PHP MySQL server. We use AndroidNetworking as our HTTP Client.

Here's the tutorial: [https://camposha.info/android-examples/mysql-upload-retrieve-images-gridview](https://camposha.info/android-examples/mysql-upload-retrieve-images-gridview)

Here's the video tutorial: [https://youtu.be/Zur4HXRbCfU](https://youtu.be/Zur4HXRbCfU)
